sap.ui.jsview("com.demo.view.Main", {

	/** Specifies the Controller belonging to this View. 
	 * In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	 * @memberOf controller.Main
	 */
	getControllerName: function() {
		return "com.demo.controller.Main";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	 * Since the Controller is given to this method, its event handlers can be attached right away.
	 * @memberOf controller.Main
	 */
	createContent: function(oController) {
		
		// Page 1
		var oLayout = new sap.ui.layout.form.SimpleForm("formId", {
			content: [
				new sap.ui.commons.Label({
					text: "Enter Table Name:",
					width: '200px'
				}).addStyleClass("sapUiSmallMarginBegin").addStyleClass("sapUiSmallMarginTop"),
				new sap.ui.commons.TextField("tableId", {
					width: "300px",
					required: true,
					text:"T_IOT_1588D9AFF22F16B0C6DB",
//					editable:"false"
//					placeholder: "T_IOT_XYZ1234567890",
					tooltip: "Enter Table Name"
				}).addStyleClass("sapUiSmallMarginBegin").addStyleClass("sapUiSmallMarginTop"),

				new sap.ui.commons.Label({
					text: "Select Refresh Rate:",
					width: '200px'
				}).addStyleClass("sapUiSmallMarginBegin").addStyleClass("sapUiSmallMarginTop"),
				new sap.ui.commons.DropdownBox("dropdownId", {
					width: "300px",
					required: true,
					editable: true,
					items: [
						new sap.ui.core.ListItem("justOnceId", {
							text: 'Just Once'
						}),
						new sap.ui.core.ListItem("twoId", {
							text: '2 Seconds'
						}),
						new sap.ui.core.ListItem("fiveId", {
							text: '5 Seconds'
						}),
						new sap.ui.core.ListItem("tenId", {
							text: '10 Seconds'
						}),
					]
				}).addStyleClass("sapUiSmallMarginBegin").addStyleClass("sapUiSmallMarginTop"),

				new sap.ui.commons.Label({
					text: "",
					width: '200px'
				}).addStyleClass("sapUiSmallMarginBegin").addStyleClass("sapUiSmallMarginTop"),
				new sap.ui.commons.Button("startButtonId", {
					text: "Start",
					width: "100px",
					press: function() {
						oController._eventHandler("start");
						app.to("page2");
					}
				}).addStyleClass("sapUiSmallMarginBegin").addStyleClass("sapUiSmallMarginTop"),
				new sap.ui.commons.Label({
					text: "",
					width: '200px'
				}).addStyleClass("sapUiSmallMarginBegin").addStyleClass("sapUiSmallMarginTop"),
				new sap.ui.commons.Button("stopButtonId", {
					text: "Stop",
					width: "100px",
					enabled: false,
					press: function() {
						oController._eventHandler("stop");
					}
				}).addStyleClass("sapUiSmallMarginBegin").addStyleClass("sapUiSmallMarginTop")
			]
		});
		//End of Page 1

		// Page 2
		// Cells
		var oCellX = new sap.m.Text({
			text: "{C_ACCX}"
		});
		var oCellY = new sap.m.Text({
			text: "{C_ACCY}"
		});
		var oCellZ = new sap.m.Text({
			text: "{C_ACCZ}"
		});
		var oCellAudio = new sap.m.Text({
			text: "{C_AUDIO}"
		});
		// Corresponding Columns
		var col1 = new sap.m.Column("col1", {
			header: new sap.m.Label({
				text: "Accelerometer X"
			})
		});
		var col2 = new sap.m.Column("col2", {
			header: new sap.m.Label({
				text: "Accelerometer Y"
			})
		});
		var col3 = new sap.m.Column("col3", {
			header: new sap.m.Label({
				text: "Accelerometer Z"
			})
		});
		var col4 = new sap.m.Column("col4", {
			header: new sap.m.Label({
				text: "Audio"
			})
		});
		// Row Template
		var oRow = new sap.m.ColumnListItem();
		oRow.addCell(oCellX).addCell(oCellY).addCell(oCellZ).addCell(oCellAudio);
		// Table
		var oTable = sap.m.Table("mainTable", {
			inset: false,
			headerText: "List of data points from IoT Service"
		});
		oTable.addColumn(col1).addColumn(col2).addColumn(col3).addColumn(col4);
		// Binding
		oTable.bindItems("/items", oRow);
		// End of Page 2

		// Page 3
		var vizFrame = new sap.viz.ui5.controls.VizFrame("graph").addStyleClass("sapUiSmallMarginBegin").addStyleClass("sapUiSmallMarginTop");
		vizFrame.setWidth("900px");
        var oDataset = new sap.viz.ui5.data.FlattenedDataset({
            dimensions: [
                {
                	name: "Date",
                    value: {
                    	path: "G_CREATED",
                    	formatter: function(val){
                    		if (val == null) {
                    			return "string null";
                    		}                   		
                    		var date = new Date(parseInt(val.substr(6,20)));
                    		var dd = date.getDate();
                            var mm = date.getMonth()+1; //January is 0!
                            var yyyy = date.getFullYear();
                            var hr = date.getHours();
                            var min = date.getMinutes();
                            var sec = date.getSeconds();
                            var fromdate1 = dd+'/'+mm+'/'+yyyy + " " + hr + ":" + min + ":" + sec;
                    		return fromdate1;
                    	}
                    }
                }
            ],
            measures: [
                {
                	name: "AccelerometerX",
                    value: "{C_ACCX}"
                },
                {
                	name: "AccelerometerY",
                    value: "{C_ACCY}"
                },
                {
                	name: "AccelerometerZ",
                    value: "{C_ACCZ}"
                }
            ],
            data: {
                path: "/items"
        		
            }
        });
        vizFrame.setDataset(oDataset);
        vizFrame.setVizType('line');
        
        vizFrame.setVizProperties({
            plotArea: {
            	colorPalette :  ["#5cbae6", "#b6d957", "#fac364"]
                },
            categoryAxis: {
            	title: {
            		text: "Date/Time"
            	}
            },
            valueAxis: {
            	title: {
            		text: "Accelerometer"
            	}
            },
            title: {
            	visible:false
            }
		});
		
		var feedValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
		      'uid': "valueAxis",
		      'type': "Measure",
		      'values': ["AccelerometerX", "AccelerometerY", "AccelerometerZ"]
		    }), 
		    feedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
		      'uid': "categoryAxis",
		      'type': "Dimension",
		      'values': ["Date"]
		    });
        
        vizFrame.addFeed(feedValueAxis);
        vizFrame.addFeed(feedCategoryAxis);
        
        var container = new sap.m.VBox({
            items: [vizFrame],
            width: "100%",
            height: "100%",
            alignItems: "Center"
        });
		// End of Page 3

		// Page Structure	    
		var app = new sap.m.App("myApp", {
			initialPage: "oPage"
		});

		var navButton1 = new sap.m.Button({
			text: "View Table",
			press: function() {
				// navigate to page2
				app.to("page2");
			}
		});

		var navButton2 = new sap.m.Button({
			text: "View Chart",
			press: function() {
				// navigate to page3
				app.to("page3");
			}
		});

		var page1 = new sap.m.Page("page1", {
			title: "{i18n>page1Title}",
			showNavButton: false,
			content: [navButton1, oLayout]
		});

		var page2 = new sap.m.Page("page2", {
			title: "{i18n>page2Title}",
			content: [navButton2, oTable],
			showNavButton: true,
			navButtonPress: function() {
				// go back to the previous page
				app.back();
			}
		});

		var page3 = new sap.m.Page("page3", {
			title: "{i18n>page3Title}",
			content: [container],
			showNavButton: true,
			navButtonPress: function() {
				// go back to the previous page
				app.back();
			}
		});
		// End of Page Structure

		app.addPage(page1).addPage(page2).addPage(page3);
		return app;
	}

});