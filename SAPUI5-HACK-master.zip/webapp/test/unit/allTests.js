sap.ui.define([
	"saom/com/samplemap/shwetang28/test/unit/controller/View1.controller"
], function () {
	"use strict";
});