sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("saom.com.samplemap.shwetang28.controller.Map", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf saom.com.samplemap.shwetang28.SAPUI5-HACK-master.view.map
		 */
		onInit: function () {
			//var globalThis;			
			var that = this;
			$.ajax({
				type: "GET",
				//async: false,
				//crossDomain: true,
				url: 'https://maps.googleapis.com/maps/api/js?key=AIzaSyAWAb0Dr2cDdOicUsKYqBGMcscdV79Nutg&v=3',
				dataType: "jsonp",
				success: function (data, status, jqXHR) { //success function works when above connection is successfull.
					//alert("connection successful");
					//that.init(this, data);
				},
				error: function (e) { //success function works when above connection fails.
					self.error_msg("Error encountered. check connection and reload.");
				}
			}).done(function () {
				that.init(window);
			});
		},
		init: function (data) {
			//		alert("initialize");

			var map;
			map = new data.google.maps.Map(document.getElementById("map"), {
				zoom: 4,
				center: {
					lat: 17.4622524,
					lng: 78.3697912
				} //Initial Location on Map
			});

		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf saom.com.samplemap.shwetang28.SAPUI5-HACK-master.view.map
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf saom.com.samplemap.shwetang28.SAPUI5-HACK-master.view.map
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf saom.com.samplemap.shwetang28.SAPUI5-HACK-master.view.map
		 */
		//	onExit: function() {
		//
		//	}

	});

});