// sap.ui.define(["./Module"], function() {
//     return {
//         customMethod : function() {
//             var strin = "My Module data";
//             return strin;
//         }
//     };
// });